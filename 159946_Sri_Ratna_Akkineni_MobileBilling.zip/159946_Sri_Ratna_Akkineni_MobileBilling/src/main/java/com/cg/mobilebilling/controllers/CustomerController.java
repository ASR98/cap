package com.cg.mobilebilling.controllers;
import java.util.List;

import javax.naming.Binding;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
@Controller
public class CustomerController {
	@Autowired
	BillingServices billingServices;

	@RequestMapping("/customerRegistration")
	public ModelAndView acceptCustomerDetails(@Valid@ ModelAttribute Customer customer,BindingResult bindingResult) throws BillingServicesDownException {
		if(bindingResult.hasErrors())
			return new ModelAndView("registerCustomerPage");
		customer=billingServices.acceptCustomerDetails(customer);
		return new ModelAndView("customerRegistrationSuccessPage","customer",customer);
	}
	@RequestMapping("/postpaidAccount")
	public ModelAndView openPostpaidMobileAccount(@RequestParam int customerID,@RequestParam int planID) throws CustomerDetailsNotFoundException, BillingServicesDownException {
		try {
			long mobileNumber = billingServices.openPostpaidMobileAccount(customerID, planID);
			return new ModelAndView("PostpaidAccountSuccessPage","mobileNumber",mobileNumber);
		} catch (PlanDetailsNotFoundException e) {
			return new ModelAndView("createPostpaidAccountPage","error",e.getMessage());
		}

	}
	@RequestMapping("/getCustomer")
	public ModelAndView getCustomerDetails(@RequestParam int customerID) throws CustomerDetailsNotFoundException, BillingServicesDownException{
		Customer customer = billingServices.getCustomerDetails(customerID);
		return new ModelAndView("customerDetailsPage","customer",customer);
	}
	@RequestMapping("/getAllPlanDetails")
	public ModelAndView getPlanAllDetails() throws BillingServicesDownException{
		List<Plan>plans=billingServices.getPlanAllDetails();
		return new ModelAndView("getAllPlanDetailsPage","plans",plans);
	}
	@RequestMapping("/mobileBillGeneration")
	public ModelAndView generateMonthlyMobileBill(@RequestParam int customerID,@RequestParam long mobileNo,@RequestParam String billMonth,@RequestParam int noOfLocalSMS,
			@RequestParam int noOfStdSMS,@RequestParam int noOfLocalCalls,@RequestParam int noOfStdCalls,@RequestParam int internetDataUsageUnits) throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, PlanDetailsNotFoundException{
		Bill bill = billingServices.generateMonthlyMobileBill(customerID, mobileNo, billMonth, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits);
		return new ModelAndView("mobileBillPage","bill",bill);
	}

	@RequestMapping("/postpaidAccountDetails")
	public ModelAndView getpostpaidAccountDetails(@RequestParam int customerID,@RequestParam long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException{
		PostpaidAccount postpaid= billingServices.getPostPaidAccountDetails(customerID, mobileNo);
		return new ModelAndView("postpaidAccountDetailsPage","postpaid",postpaid);
	}
	@RequestMapping("/getAllCustomerDetails")
	public ModelAndView getAllCustomerDetails() throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		List<Customer>customers=billingServices.getAllCustomerDetails();
		return new ModelAndView("getAllCustomerDetailsPage","customers",customers);
	}
	@RequestMapping("/customerAllPostpaidAccountDetails")
	public ModelAndView getCustomerAllPostpaidAccountDetails(@RequestParam int customerID) throws BillingServicesDownException, CustomerDetailsNotFoundException{
		List<PostpaidAccount> postpaids = billingServices.getCustomerAllPostpaidAccountsDetails(customerID);
		return new ModelAndView("customerAllPostpaidAccountDetailsPage","postpaids",postpaids);
	}
	@RequestMapping("/mobileBillDetails")
	public ModelAndView getmobileBillDetails(@RequestParam int customerID,@RequestParam long mobileNo,@RequestParam String billMonth) throws BillingServicesDownException,PostpaidAccountNotFoundException, BillDetailsNotFoundException, CustomerDetailsNotFoundException, InvalidBillMonthException {
		Bill bill = billingServices.getMobileBillDetails(customerID, mobileNo, billMonth);
		return new ModelAndView("mobileBillDetailsPage","bill",bill);
	}
	@RequestMapping("/getAllBillDetails")
	public ModelAndView getmobileAllBillDetails(@RequestParam int customerID,@RequestParam long mobileNo) throws BillingServicesDownException, PlanDetailsNotFoundException, BillDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		List<Bill> bills = billingServices.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);
		return new ModelAndView("mobileAllBillDetailsPage","bills",bills);
	}
	@RequestMapping("/changePlanDetails")
	public ModelAndView changePlanDetails(@RequestParam int customerID,@RequestParam long mobileNo, @RequestParam int planID) throws BillingServicesDownException, InvalidBillMonthException, BillDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		billingServices.changePlan(customerID, mobileNo, planID);
		return new ModelAndView("planChangeSuccessPage");
	}
	@RequestMapping("/postpaidAccountPlanDetails")
	public ModelAndView getpostpaidAccountPlanDetails(@RequestParam int customerID,@RequestParam long mobileNo) throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		Plan plan = billingServices.getCustomerPostPaidAccountPlanDetails(customerID, mobileNo);
		return new ModelAndView("postpaidAccountPlanDetailsPage","plan",plan);
	}
	@RequestMapping("/deleteCustomerDetails")
	public ModelAndView deleteCustomerDetails(@RequestParam int customerID) throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException{
		billingServices.deleteCustomer(customerID);
		return new ModelAndView("deletionSuccessulPage");
	}
	@RequestMapping("/closeCustomerPostpaidAccount")
	public ModelAndView closePostpaidAccount(@RequestParam int customerID,@RequestParam long mobileNo) throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		billingServices.closeCustomerPostPaidAccount(customerID, mobileNo);
		return new ModelAndView("postpaidAccountClosedPage");

	}
}
