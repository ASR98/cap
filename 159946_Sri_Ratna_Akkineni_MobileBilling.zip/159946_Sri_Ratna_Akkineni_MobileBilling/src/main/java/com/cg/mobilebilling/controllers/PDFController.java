package com.cg.mobilebilling.controllers;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
import com.cg.mobilebilling.util.GeneratePDF;
import com.itextpdf.text.DocumentException;

@RestController
public class PDFController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping (value = "/customerPdfReport", method = RequestMethod.GET,
			produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> allCustomerDetails() throws IOException, BillingServicesDownException, DocumentException{
		List<Customer> customers = (List<Customer>) billingServices.getAllCustomerDetails();
		ByteArrayInputStream bis = GeneratePDF.allCustomerDetails(customers);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "inline; filename=CustomerDetails.pdf");

		return ResponseEntity
				.ok()
				.headers(headers)
				.contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(bis));

	}
	@RequestMapping (value = "/billPdfReport", method = RequestMethod.POST,
			produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> customerAllBillDetails(@RequestParam int customerID, @RequestParam long mobileNo) throws IOException, BillingServicesDownException, DocumentException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException{
		List<Bill> bills = (List<Bill>) billingServices.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);
		ByteArrayInputStream bis = GeneratePDF.customerAllBillDetails(bills);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "inline; filename=AllBillDetails.pdf");

		return ResponseEntity
				.ok()
				.headers(headers)
				.contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(bis));
	}
	@RequestMapping (value = "/singleBillPdfReport", method = RequestMethod.POST,
			produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> customerBillDetails(@RequestParam int customerID, @RequestParam long mobileNo,@RequestParam String billMonth) throws IOException, BillingServicesDownException, DocumentException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException{
		Bill bill = billingServices.getMobileBillDetails(customerID, mobileNo, billMonth);
		ByteArrayInputStream bis = GeneratePDF.customerBillDetails(bill);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "inline; filename=BillDetails.pdf");

		return ResponseEntity
				.ok()
				.headers(headers)
				.contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(bis));
	}
}
