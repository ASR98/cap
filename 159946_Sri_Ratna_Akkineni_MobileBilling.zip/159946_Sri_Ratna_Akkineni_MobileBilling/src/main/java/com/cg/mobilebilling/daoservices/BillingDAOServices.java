package com.cg.mobilebilling.daoservices;
import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.PostpaidAccount;
@Transactional
public interface BillingDAOServices extends JpaRepository<Bill, Integer>{
	@Query("select a from Bill a where a.postpaidAccount=:postpaidAccount and a.billMonth=:billMonth")
	Bill getMobileBillDetails(@Param("postpaidAccount") PostpaidAccount postpaidAccount,@Param("billMonth") String billMonth);	
	@Modifying
	@Query("delete from Bill a where a.postpaidAccount=:postpaidAccount")
	void deleteBills(@Param("postpaidAccount") PostpaidAccount postpaidAccount);

}