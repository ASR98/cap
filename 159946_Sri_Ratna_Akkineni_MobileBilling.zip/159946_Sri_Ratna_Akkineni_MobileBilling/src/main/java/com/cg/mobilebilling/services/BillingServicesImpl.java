package com.cg.mobilebilling.services;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAOServices;
import com.cg.mobilebilling.daoservices.PlanDAOServices;
import com.cg.mobilebilling.daoservices.PostpaidDAOServices;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
@Component("billingServices")
public class BillingServicesImpl implements BillingServices {
	@Autowired
	BillingDAOServices billingDAO;
	@Autowired
	CustomerDAOServices customerDAO;
	@Autowired
	PlanDAOServices planDAO;
	@Autowired
	PostpaidDAOServices postpaidDAO;

	@Override
	public Customer acceptCustomerDetails(Customer customer) throws BillingServicesDownException {
		customerDAO.save(customer);
		return customer;
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found!!!"));
		Plan plan=planDAO.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException("Please check Plan Details before selection!!!!"));
		PostpaidAccount postpaid=new PostpaidAccount(plan, customer);
		postpaidDAO.save(postpaid);
		return postpaid.getMobileNo();
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		return customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer Details Not Found"));
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		return customerDAO.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found"));
		PostpaidAccount postpaid=postpaidDAO.getPostPaidAccountDetails(customer, mobileNo);
		if(postpaid==null) throw new PostpaidAccountNotFoundException("Sorry!!PostPaid Account is not found");
		return postpaid;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer details not found!!!"));
		List<PostpaidAccount> postpaid=new ArrayList<>();
		postpaid=postpaidDAO.getCustomerAllPostpaidAccountsDetails(customer);
		return postpaid;
	}
	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer details not found!!!"));
		PostpaidAccount postpaidAccount=postpaidDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("Postpaid Account not found"));
		Plan plan=postpaidDAO.getCustomerPostPaidAccountPlanDetails(customer, mobileNo);
		if(plan==null) throw new PlanDetailsNotFoundException("Plan Details Not found");
		return plan;
	}
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		ArrayList<Plan> plan = new ArrayList<>();
		Plan plan1=new Plan(1, 450, 200, 150, 100, 50, 2, 1, 1, 1, 1, 1, "A.P", "Vanilla");
		Plan plan2=new Plan(2, 250, 125, 50, 50, 25, 1, 1, 2, 1, 2, 1, "Telangana", "Powerpack");
		Plan plan3=new Plan(3, 650, 300, 200, 150, 100, 3, 1, 1, 1, 1, 1, "Vskp", "Raspberry");
		plan.add(plan1);
		plan.add(plan2);
		plan.add(plan3);
		planDAO.saveAll(plan);
		return planDAO.findAll();
	}
	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer details not found!!!"));
		PostpaidAccount postpaid=postpaidDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("Sorry Postpaid Account details not found!!!"));
		Bill bill=billingDAO.getMobileBillDetails(postpaid ,billMonth);
		if(bill==null) throw new InvalidBillMonthException("Entered Bill month dosen't exists");
		else
			return bill;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer details not found!!!"));
		postpaidDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("Sorry!!Postpaid Account Not found"));
		List<Bill> bill=new ArrayList<>();
		bill=postpaidDAO.getCustomerPostPaidAccountAllBillDetails(customer, mobileNo);
		if(bill==null) throw new BillDetailsNotFoundException("No Bills are found");
		return bill;
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
	PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer details not found!!!"));
		Plan plan=planDAO.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException("Sorry requested plan is unavailable!!!"));
		postpaidDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("PostPaid Account Not found"));
		PostpaidAccount postpaid=new PostpaidAccount(mobileNo, plan, customer);
		postpaidDAO.save(postpaid);
		return true;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer details not found!!!"));
		PostpaidAccount postpaidAccount=getPostPaidAccountDetails(customerID, mobileNo);
		if(postpaidAccount==null)
			throw new PostpaidAccountNotFoundException("Postpaid Account Not Found");
		billingDAO.deleteBills(postpaidAccount);
		postpaidDAO.closeCustomerPostPaidAccount(customer, mobileNo);
		return true;
	}
	@Override
	public Bill generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
					throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
					BillingServicesDownException, PlanDetailsNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer Not found!!"));
		Map<Long, PostpaidAccount> postpaidAccounts=customer.getPostpaidAccounts();
		if(postpaidAccounts==null || postpaidAccounts.isEmpty()) 
			throw new PostpaidAccountNotFoundException("Requested PostPaid Account does not exist!!!");
		else if(!postpaidAccounts.containsKey(mobileNo))
			throw new PostpaidAccountNotFoundException("Mobile number not found for the respective Customer Id.");
		else{
			PostpaidAccount postpaid=postpaidAccounts.get(mobileNo);
			Bill bill=new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, postpaid, billMonth);
			if(noOfLocalSMS>postpaid.getPlan().getFreeLocalSMS())
				bill.setLocalSMSAmount((noOfLocalSMS-postpaid.getPlan().getFreeLocalSMS())*postpaid.getPlan().getLocalSMSRate());
			else
				bill.setLocalSMSAmount(0);
			if(noOfStdSMS>postpaid.getPlan().getFreeStdSMS())
				bill.setStdSMSAmount((noOfStdSMS-postpaid.getPlan().getFreeStdSMS())*postpaid.getPlan().getStdSMSRate());
			else
				bill.setStdSMSAmount(0);
			if(noOfLocalCalls>postpaid.getPlan().getFreeLocalCalls())
				bill.setLocalCallAmount((noOfLocalCalls-postpaid.getPlan().getFreeLocalCalls())*postpaid.getPlan().getLocalCallRate());
			else
				bill.setLocalCallAmount(0);
			if(noOfStdCalls>postpaid.getPlan().getFreeStdCalls())
				bill.setStdCallAmount((noOfStdCalls-postpaid.getPlan().getFreeStdCalls())*postpaid.getPlan().getStdCallRate());
			else
				bill.setStdCallAmount(0);
			if(internetDataUsageUnits>postpaid.getPlan().getFreeInternetDataUsageUnits())
				bill.setInternetDataUsageAmount((internetDataUsageUnits-postpaid.getPlan().getFreeInternetDataUsageUnits())*postpaid.getPlan().getInternetDataUsageRate());
			else
				bill.setInternetDataUsageAmount(0);
			float intialamount=bill.getLocalSMSAmount()+bill.getLocalCallAmount()+bill.getStdSMSAmount()+bill.getStdCallAmount()+bill.getInternetDataUsageAmount()+postpaid.getPlan().getMonthlyRental();
			bill.setCgst((intialamount*5)/100);
			bill.setSgst((intialamount*5)/100);
			bill.setTotalBillAmount(intialamount+bill.getCgst()+bill.getSgst());
			billingDAO.save(bill);
			return bill;
		}
	}
	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer Not found!!"));
		Map<Long, PostpaidAccount> postpaidAccounts=customer.getPostpaidAccounts();
		for(Map.Entry<Long, PostpaidAccount> p:postpaidAccounts.entrySet()) {
			Long mobileNo=p.getKey();
			closeCustomerPostPaidAccount(customerID, mobileNo);
		}
		customerDAO.deleteById(customerID);
		return true;
	}
}