package com.cg.mobilebilling.boot;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.CustomerDAOServices;
import com.cg.mobilebilling.daoservices.PlanDAOServices;
import com.cg.mobilebilling.daoservices.PostpaidDAOServices;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CgMobileBillingSpringMvcjpaDataBootApplicationTests {

	@MockBean
	private  CustomerDAOServices customerDAO;
	@MockBean
	private PlanDAOServices planDAO;
	@MockBean
	private PostpaidDAOServices postpaidDAO;
	@Autowired
	private BillingServices billingServices;
	@Test
	public void acceptCustomerDetailsTest() throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer = new Customer(101,"Harry", "Potter", "harry@gmail.com", "18/07/1998", new Address(123456, "Hogwarts", "Wizardry"));
		Mockito.when(customerDAO.save(customer)).thenReturn(customer);
		assertThat(billingServices.acceptCustomerDetails(customer)).isEqualTo(customer);	
	}
	@Test
	public void getAllCustomerDetailsTest() throws BillingServicesDownException {
		Customer customer1 = new Customer(101,"Harry", "Potter", "harry@gmail.com", "18/07/1998", new Address(123456, "Hogwarts", "Wizardry"));
		Customer customer2= new Customer(102,"Hermonie", "Granger", "hermonie@gmail.com", "18/08/1998", new Address(123456, "Hogwarts", "Wizardry"));
		ArrayList<Customer> list = new ArrayList<>();
		list.add(customer1);
		list.add(customer2);
		Mockito.when(customerDAO.findAll()).thenReturn(list);
		assertThat(billingServices.getAllCustomerDetails()).isEqualTo(list);	
}
	@Test
	public void getCustomerDetailsTest() throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer = new Customer(101,"Harry", "Potter", "harry@gmail.com", "18/07/1998", new Address(123456, "Hogwarts", "Wizardry"));
		Mockito.when(customerDAO.findById(101).get()).thenReturn(customer);
		assertThat(billingServices.getCustomerDetails(101)).isEqualTo(customer);
	}
}
